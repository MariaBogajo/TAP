package Facturacion;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class FacturacionTest {

    Facturacion f = new Facturacion();

    @Test
    public void testFijoMenor100() {
        assertEquals("Carga mínima mensual", f.calcularFactura("fijo", 50));
    }

    @Test
    public void testFijoMayorIgual100() {
        assertEquals("Tarifa normal", f.calcularFactura("fijo", 150));
    }

    @Test
    public void testVariableMenor100() {
        assertEquals("Tarifa normal", f.calcularFactura("variable", 80));
    }

    @Test
    public void testVariableEntre100y500() {
        assertEquals("Normal hasta 100 + reducida el resto", f.calcularFactura("variable", 300));
    }

    @Test
    public void testVariableMayor500() {
        assertEquals("Tarifa reducida total", f.calcularFactura("variable", 700));
    }

    @Test
    public void testMetodoDesconocido() {
        assertEquals("Método desconocido", f.calcularFactura("mixto", 200));
    }
}
