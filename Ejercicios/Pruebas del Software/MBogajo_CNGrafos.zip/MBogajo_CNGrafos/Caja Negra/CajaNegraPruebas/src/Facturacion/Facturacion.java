package Facturacion;

public class Facturacion {

    public String calcularFactura(String metodo, int consumo) {
        if (metodo.equalsIgnoreCase("fijo")) {
            if (consumo < 100) {
                return "Carga mínima mensual";
            } else {
                return "Tarifa normal";
            }
        } else if (metodo.equalsIgnoreCase("variable")) {
            if (consumo < 100) {
                return "Tarifa normal";
            } else if (consumo <= 500) {
                return "Normal hasta 100 + reducida el resto";
            } else {
                return "Tarifa reducida total";
            }
        } else {
            return "Método desconocido";
        }
    }
}
