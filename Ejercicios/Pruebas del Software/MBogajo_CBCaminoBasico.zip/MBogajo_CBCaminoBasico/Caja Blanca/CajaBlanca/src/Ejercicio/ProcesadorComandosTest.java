package Ejercicio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ProcesadorComandosTest {

    ProcesadorComandos pc = new ProcesadorComandos();

    @Test
    public void testCaso1_ControlConPausa() {
        Comando c = new Comando(true, true, false, false);
        String salida = pc.procesar(c);
        assertTrue(salida.contains("Esperar continuación"));
    }

    @Test
    public void testCaso2_ControlSinPausa() {
        Comando c = new Comando(true, false, false, false);
        String salida = pc.procesar(c);
        assertTrue(salida.contains("Procesar comando"));
    }

    @Test
    public void testCaso3_NoControl_Redirige_FicheroExiste() {
        Comando c = new Comando(false, false, true, true);
        String salida = pc.procesar(c);
        assertTrue(salida.contains("Tomar la entrada desde el fichero"));
    }

    @Test
    public void testCaso4_NoControl_Redirige_FicheroNoExiste() {
        Comando c = new Comando(false, false, true, false);
        String salida = pc.procesar(c);
        assertTrue(salida.contains("Dar un mensaje de aviso"));
        assertTrue(salida.contains("Tomar la entrada desde el teclado"));
    }

    @Test
    public void testCaso5_NoControl_SinRedireccion() {
        Comando c = new Comando(false, false, false, false);
        String salida = pc.procesar(c);
        assertTrue(salida.contains("Tomar la entrada desde el teclado"));
    }
}