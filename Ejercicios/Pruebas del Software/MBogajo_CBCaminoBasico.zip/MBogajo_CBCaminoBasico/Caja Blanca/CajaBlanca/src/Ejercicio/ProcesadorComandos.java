package Ejercicio;

public class ProcesadorComandos {

    public String procesar(Comando comando) {
        StringBuilder salida = new StringBuilder();

        salida.append("Preprocesar comando\n");

        if (comando.esControl) {
            salida.append("Activar modo control\n");
            if (comando.esPausa) {
                salida.append("Esperar continuación\n");
            } else {
                salida.append("Procesar comando\n");
            }
            salida.append("Desactivar modo control\n");
        } else {
            if (comando.hayRedireccion) {
                if (comando.ficheroExiste) {
                    salida.append("Tomar la entrada desde el fichero\n");
                } else {
                    salida.append("Dar un mensaje de aviso\n");
                    salida.append("Tomar la entrada desde el teclado\n");
                }
            } else {
                salida.append("Tomar la entrada desde el teclado\n");
            }
        }

        salida.append("Ejecutar comando\n");
        salida.append("Escribir prompt para siguiente comando\n");

        return salida.toString();
    }
}

