package Ejercicio;

public class Comando {
	
    public boolean esControl;
    public boolean esPausa;
    public boolean hayRedireccion;
    public boolean ficheroExiste;

    public Comando(boolean esControl, boolean esPausa, boolean hayRedireccion, boolean ficheroExiste) {
        this.esControl = esControl;
        this.esPausa = esPausa;
        this.hayRedireccion = hayRedireccion;
        this.ficheroExiste = ficheroExiste;
    }
}

