package Fragmento3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Fragmento3Test {

    Fragmento3 f3 = new Fragmento3();

    @Test
    public void testMixto() {
        System.out.println("\n--- TEST: Mixto mayúsculas y minúsculas");
        System.out.println("Se espera que el método falle en la lógica y no convierta correctamente.");

        String salida = f3.fragmento3("AbC");
        System.out.println("Resultado: " + salida);
        assertNotEquals("abc", salida); // No debería ser el esperado
    }

    @Test
    public void testSoloMayusculas() {
        System.out.println("\n--- TEST: Solo MAYÚSCULAS");
        System.out.println("Esperamos que se conviertan a minúsculas, pero no lo hace.");

        String salida = f3.fragmento3("HOLA");
        System.out.println("Resultado: " + salida);
        assertNotEquals("hola", salida); // La lógica es incorrecta
    }

    @Test
    public void testCadenaVacia() {
        System.out.println("\n--- TEST: Cadena vacía");
        System.out.println("No debería lanzar error, pero lo hace por j desfasado.");
        assertThrows(StringIndexOutOfBoundsException.class, () -> {
            f3.fragmento3(""); // Tir.charAt(j) rompe con cadena vacía
        });
    }
    
    @Test
    public void testSoloMinusculas() {
        System.out.println("\n--- TEST: Solo minúsculas");
        System.out.println("La condición evalúa que ya son minúsculas y les suma 32 → caracteres raros.");

        String salida = f3.fragmento3("hola");
        System.out.println("Resultado: " + salida);
        assertNotEquals("hola", salida); // Se transforma erróneamente
    }
}

