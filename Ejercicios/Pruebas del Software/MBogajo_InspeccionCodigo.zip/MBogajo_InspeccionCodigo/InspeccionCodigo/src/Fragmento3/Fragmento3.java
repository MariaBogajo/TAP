package Fragmento3;

public class Fragmento3 {

    public String fragmento3(String Tir) {
        int j = 0;
        StringBuilder resultado = new StringBuilder();
        for (int i = 0; i < Tir.length(); i++); { 
            if (Tir.charAt(j) > 'a' & Tir.charAt(j) < 'z') { 
                resultado.append((char)(Tir.charAt(j) + 32)); 
                j++;
            }
        }
        return resultado.toString();
    }
}

