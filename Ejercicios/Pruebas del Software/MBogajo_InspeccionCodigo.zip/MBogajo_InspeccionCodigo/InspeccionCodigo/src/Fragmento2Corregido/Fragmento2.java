package Fragmento2Corregido;

public class Fragmento2 {
	
    public char[] separarCaracteres(String tir) {
        if (tir == null) {
            return new char[0];
        }

        int longitud = tir.length();
        char[] separador = new char[longitud];

        for (int i = 0; i < longitud; i++) {
            separador[i] = tir.charAt(i);
        }

        return separador;
    }
}

