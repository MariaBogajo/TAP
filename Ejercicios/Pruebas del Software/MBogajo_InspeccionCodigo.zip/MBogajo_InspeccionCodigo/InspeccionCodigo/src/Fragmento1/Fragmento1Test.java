package Fragmento1;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.Duration;

public class Fragmento1Test {

    Fragmento1 f1 = new Fragmento1();

    // 🔹 Test 1: nBytes negativo
    @Test
    public void test_nBytesNegativo() {
        System.out.println("\n --- TEST: nBytes NEGATIVO");
        System.out.println("Comprobamos que el método acepta un valor negativo sin lanzar error,");
        System.out.println("lo que indica falta de validación de entrada.");
        f1.ejecutar(-5);
    }

    // 🔹 Test 2: nBytes demasiado grande
    @Test
    public void test_nBytesDemasiadoGrande() {
        System.out.println("\n --- TEST: nBytes DEMASIADO GRANDE");
        System.out.println("Comprobamos que se ejecuta con un valor enorme (10.000),");
        System.out.println("lo que puede saturar la salida sin control.");
        assertTimeout(Duration.ofSeconds(1), () -> f1.ejecutar(10_000));
    }

    // 🔹 Test 3: nBytes igual a cero
    @Test
    public void test_nBytesCero() {
        System.out.println("\n --- TEST: nBytes IGUAL A CERO");
        System.out.println("Comprobamos que el bucle no se ejecuta si nBytes es 0,");
        System.out.println("pero no hay feedback ni validación.");
        f1.ejecutar(0);
    }

    // 🔹 Test 4: valor correcto
    @Test
    public void test_nBytesValido() {
        System.out.println("\n --- TEST: nBytes CORRECTO");
        System.out.println("Comprobamos que se ejecuta correctamente con un valor válido (5).");
        f1.ejecutar(5);
    }
}
