package Fragmento1;

public class Fragmento1 {

    public void ejecutar(int nBytes) {
        int c;
        System.err.printf("\n_length= %d.\n", nBytes);
        for (int i = 0; i < nBytes; i++) {
            c = 65 + i;
            System.out.printf("%c", c);
        }
    }
}
