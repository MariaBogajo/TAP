package Fragmento1Corregido;

public class Fragmento1 {

    public void ejecutar(int nBytes) {
        if (nBytes < 0 || nBytes > 26) {
            System.out.println("El valor de nBytes debe estar entre 0 y 26.");
            return;
        }

        System.out.printf("\n_length= %d.\n", nBytes);

        for (int i = 0; i < nBytes; i++) {
            System.out.printf("%c", 'A' + i);
        }

        System.out.println();
    }
}

