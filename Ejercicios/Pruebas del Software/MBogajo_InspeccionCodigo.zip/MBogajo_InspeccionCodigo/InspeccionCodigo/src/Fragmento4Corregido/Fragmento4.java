package Fragmento4Corregido;

public class Fragmento4 {

    public String fragmento4(String tir, String spo) {
        if (tir == null || spo == null || spo.isEmpty()) {
            return null;
        }

        int index = tir.indexOf(spo);
        if (index != -1) {
            return tir.substring(0, index); // Retorna hasta el delimitador
        } else {
            return tir; // Si no se encuentra el delimitador, retorna toda la cadena
        }
    }
}

