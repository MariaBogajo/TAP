package Fragmento4;

public class Fragmento4 {
	
	public String fragmento4(String Tir, String Spo) {
	    int i = 0, j = 0;
	    StringBuilder TirAux = new StringBuilder();
	    String Token;

	    if (Tir != null) {
	        while (Tir.charAt(i) != '\0' || !Tir.equals(Spo)) { 
	            TirAux.append(Tir.charAt(i));
	            i++;
	            j++;
	        }
	        Token = TirAux.toString();
	        return Token;
	    } else {
	        return null;
	    }
	}

}
