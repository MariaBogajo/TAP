package Fragmento4;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class Fragmento4Test {

    Fragmento4 f4 = new Fragmento4();

    @Test
    public void testTirNull() {
        System.out.println("\n--- TEST: Tir = null");
        System.out.println("Debe devolver null sin lanzar excepción.");
        String salida = f4.fragmento4(null, "spoiler");
        assertNull(salida);
    }

    @Test
    public void testTirEqualsSpo() {
        System.out.println("\n--- TEST: Tir == Spo");
        System.out.println("Aunque las cadenas son iguales, entra al bucle por el OR.");
        assertThrows(StringIndexOutOfBoundsException.class, () -> {
            f4.fragmento4("igual", "igual");
        });
    }

    @Test
    public void testSinCaracterNulo() {
        System.out.println("\n--- TEST: Tir sin carácter '\\0'");
        System.out.println("No tiene carácter de fin explícito → bucle infinito o excepción.");
        assertThrows(StringIndexOutOfBoundsException.class, () -> {
            f4.fragmento4("texto sin fin", "otra cosa");
        });
    }

    @Test
    public void testConCaracterNuloManual() {
        System.out.println("\n--- TEST: Tir con '\\0' manual");
        System.out.println("Inserta carácter nulo en mitad de la cadena. Se espera corte en ese punto o excepción.");

        assertThrows(StringIndexOutOfBoundsException.class, () -> {
            f4.fragmento4("abc\0xyz", "otro");
        });
    }

}
