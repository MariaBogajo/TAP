package Fragmento2;

public class Fragmento2 {
	
    public char[] Fragmento2(String Tir) {
        int i = 0;
        char[] separador = new char[100];

        if (Tir != null) {
            while (Tir.charAt(i) != '\0') {
                separador[i] = Tir.charAt(i);
                i++;
            }
        }
        return separador;
    }
}
