package Fragmento2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class Fragmento2Test {

    Fragmento2 f2 = new Fragmento2();

    @Test
    public void test_TirNormal_sinCaracterCero() {
        System.out.println("\n --- TEST: Tir sin carácter de fin '\\0'");
        System.out.println("Esperamos excepción por recorrer fuera de rango.");
        assertThrows(StringIndexOutOfBoundsException.class, () -> {
            f2.Fragmento2("Hola mundo");
        });
    }

    @Test
    public void test_TirConCaracterCero() {
        System.out.println("\n --- TEST: Tir con carácter '\\0' intermedio");
        System.out.println("Debería parar al llegar al \\0.");
        char[] resultado = f2.Fragmento2("Ho\u0000la");
        assertEquals('H', resultado[0]);
        assertEquals('o', resultado[1]);
    }

    @Test
    public void test_TirNull() {
        System.out.println("\n --- TEST: Tir == null");
        System.out.println("No lanza excepción, pero no hace nada.");
        assertDoesNotThrow(() -> f2.Fragmento2(null));
    }

    @Test
    public void test_TirCortoPeroDesborda() {
        System.out.println("\n --- TEST: Tir muy corto sin \\0");
        System.out.println("Debería dar error rápidamente por fuera de rango.");
        assertThrows(StringIndexOutOfBoundsException.class, () -> {
            f2.Fragmento2("A"); // nunca encuentra \0
        });
    }
}

