package Fragmento3Corregido;

public class Fragmento3 {

    public String convertirMinusculasAMayusculas(String tir) {
        if (tir == null) return "";

        StringBuilder resultado = new StringBuilder();

        for (int i = 0; i < tir.length(); i++) {
            char c = tir.charAt(i);
            if (c >= 'a' && c <= 'z') {
                resultado.append((char)(c - 32)); // Convertir a mayúscula
            } else {
                resultado.append(c); // Mantener el carácter original
            }
        }

        return resultado.toString();
    }
}

