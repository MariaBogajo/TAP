package Ejercicio;

import java.io.IOException;

public class ContadorCorregido {

	    public static void impresion(int nCar, int nPal, int nLin) {
	        System.out.println("Caracteres: " + nCar);
	        System.out.println("Palabras: " + nPal);
	        System.out.println("Líneas: " + nLin);
	    }

	    public static void main(String[] args) throws IOException {
	        char car, anterior = ' '; // Inicializar 'anterior'
	        int nCar = 0, nPal = 0, nLin = 0; // Inicializar contadores

	        int input = System.in.read();
	        car = (char) input;

	        while (input != -1) { // -1 = EOF
	            nCar++;

	            if (car == '\n') {
	                nLin++;
	            }

	            if (car != ' ' && anterior == ' ') {
	                nPal++;
	            }

	            anterior = car;
	            input = System.in.read();
	            car = (char) input;
	        }

	        impresion(nCar, nPal, nLin); // Llamada correcta al método definido
	    }
	}

