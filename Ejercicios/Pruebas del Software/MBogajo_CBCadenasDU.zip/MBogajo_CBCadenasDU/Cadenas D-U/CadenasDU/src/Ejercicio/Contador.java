package Ejercicio;

import java.io.*;

public class Contador {
    public static void main(String[] args) throws IOException {
        char car, anterior;                          //ANOMALÍA: 'anterior' no inicializado
        int nCar, nPal, nLin;                        //ANOMALÍA: variables no inicializadas

        car = (char) System.in.read();
        while (car != -1) {
            nCar = nCar + 1;                         //ANOMALÍA: uso sin inicializar

            if (car == '\n') {
                nLin = nLin + 1;                     //ANOMALÍA: uso sin inicializar
            }

            if ((car != ' ') && (anterior == ' ')) { //ANOMALÍA: uso de 'anterior' sin definir
                nPal = nPal + 1;                     //ANOMALÍA: uso sin inicializar
            }

            anterior = car;
            car = Character.toUpperCase(car);        //ANOMALÍA: redefinición sin uso posterior
            car = (char) System.in.read();
        }

        impresiOn(nCar, nPal, nLin);                 //ANOMALÍA: método no definido
    }
}
