package Ejercicio;

public class ObserverPatternDemo2 {
    public static void main(String[] args) {
        Subject subject = new Subject();

        // Prueba 1: Agregar múltiples observadores
        System.out.println("PRUEBA 1: Agregar múltiples observadores.");
        HexaObserver hexaObserver = new HexaObserver(subject);
        OctalObserver octalObserver = new OctalObserver(subject);
        BinaryObserver binaryObserver = new BinaryObserver(subject);

        System.out.println("Cambio de estado a 15:");
        subject.setState(15);

        // Prueba 2: Eliminar un observador
        System.out.println("\nPRUEBA 2: Eliminar BinaryObserver y cambiar el estado.");
        subject.detach(binaryObserver);  // Ahora este método está definido
        System.out.println("Cambio de estado a 10:");
        subject.setState(10);  // Solo HexaObserver y OctalObserver deben reaccionar

        // Prueba 3: Cambios rápidos de estado
        System.out.println("\nPRUEBA 3: Cambios rápidos de estado.");
        System.out.println("Cambio de estado a 5:");
        subject.setState(5);
        System.out.println("Cambio de estado a 20:");
        subject.setState(20);
    }
}
