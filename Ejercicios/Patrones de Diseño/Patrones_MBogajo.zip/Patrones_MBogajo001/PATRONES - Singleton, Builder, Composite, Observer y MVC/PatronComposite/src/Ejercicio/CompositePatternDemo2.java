package Ejercicio;

public class CompositePatternDemo2 {
    public static void main(String[] args) {
        
        // Creación de empleados
        Employee CEO = new Employee("John", "CEO", 30000);
        Employee headSales = new Employee("Robert", "Head Sales", 20000);
        Employee headMarketing = new Employee("Michel", "Head Marketing", 20000);

        Employee clerk1 = new Employee("Laura", "Marketing", 10000);
        Employee clerk2 = new Employee("Bob", "Marketing", 10000);
        Employee salesExecutive1 = new Employee("Richard", "Sales", 10000);
        Employee salesExecutive2 = new Employee("Rob", "Sales", 10000);

        // Construcción de la jerarquía
        CEO.add(headSales);
        CEO.add(headMarketing);
        headSales.add(salesExecutive1);
        headSales.add(salesExecutive2);
        headMarketing.add(clerk1);
        headMarketing.add(clerk2);

        // Prueba 1: Agregar un empleado de rango superior como subordinado
        System.out.println("\nPRUEBA 1: Agregar CEO como subordinado de un jefe de departamento.");
        headMarketing.add(CEO); // Esto generará una relación jerárquica incorrecta
        System.out.println("Subordinados de Head Marketing después de agregar CEO:");
        for (Employee e : headMarketing.getSubordinates()) {
            System.out.println(e);
        }

        // Prueba 2: Eliminar un jefe de departamento
        System.out.println("\nPRUEBA 2: Eliminar Head Sales de la estructura.");
        CEO.remove(headSales);
        System.out.println("Subordinados del CEO después de eliminar Head Sales:");
        for (Employee e : CEO.getSubordinates()) {
            System.out.println(e);
        }

        // Prueba 3: Crear una estructura más profunda
        System.out.println("\nPRUEBA 3: Agregar un Gerente Regional bajo un Ejecutivo de Ventas.");
        Employee newManager = new Employee("Alice", "Regional Manager", 15000);
        salesExecutive1.add(newManager);
        System.out.println("Subordinados de Sales Executive 1 después de agregar un Gerente Regional:");
        for (Employee e : salesExecutive1.getSubordinates()) {
            System.out.println(e);
        }
    }
}

