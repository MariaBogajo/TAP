package Ejercicio;

public class MVCPatternDemo2 {
    public static void main(String[] args) {
        // Crear modelo y vista
        Student model = new Student();
        model.setName("Robert");
        model.setRollNo("10");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);

        // Prueba 1: Actualizar múltiples datos del modelo y verificar la vista
        System.out.println("PRUEBA 1: Actualizar datos del estudiante");
        controller.updateView();
        controller.setStudentName("John");
        controller.setStudentRollNo("20");
        controller.updateView(); // Se deben reflejar los cambios

        // Prueba 2: Intentar actualizar la vista sin modificar el modelo
        System.out.println("\nPRUEBA 2: Llamar a updateView() sin cambiar los datos");
        controller.updateView(); // No debería haber cambios adicionales

        // Prueba 3: Crear múltiples controladores para el mismo modelo
        System.out.println("\nPRUEBA 3: Crear otro controlador para el mismo modelo");
        StudentController controller2 = new StudentController(model, view);
        controller2.setStudentName("Alice");  // Se debe reflejar en ambos controladores
        controller.updateView(); // Se debe ver "Alice" en la vista
    }
}

