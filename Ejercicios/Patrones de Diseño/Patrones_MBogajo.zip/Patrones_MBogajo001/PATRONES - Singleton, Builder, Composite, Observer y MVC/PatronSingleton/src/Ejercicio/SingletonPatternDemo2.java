package Ejercicio;

public class SingletonPatternDemo2 {
   public static void main(String[] args) {

      // Obtener la única instancia disponible
      SingleObject object1 = SingleObject.getInstance();
      
      // Mostrar el mensaje inicial
      System.out.print("Object1 mensaje antes: ");
      object1.showMessage();

      // Intentar obtener una segunda instancia
      SingleObject object2 = SingleObject.getInstance();

      // Verificar si ambas referencias apuntan al mismo objeto
      boolean sameInstance = (object1 == object2);
      System.out.println("Misma Instancia: " + sameInstance);

      // Modificar el estado del Singleton usando object1
      object1.setMessage("Nuevo mensaje Singleton");

      // Mostrar mensajes después de la modificación
      System.out.print("Object1 mensaje después: ");
      object1.showMessage();
      System.out.print("Object2 mensaje después: ");
      object2.showMessage();
   }
}


