package Ejercicio;

public class SingleObject {

   // Crear una única instancia de la clase
   private static SingleObject instance = new SingleObject();

   // Atributo de estado para prueba (no debe ser estático)
   private String message;

   // Hacer el constructor privado para evitar instanciación
   private SingleObject(){
      this.message = "Hello World!";
   }

   // Obtener la única instancia disponible
   public static SingleObject getInstance(){
      return instance;
   }

   // Método para mostrar el mensaje
   public void showMessage(){
      System.out.println(message);
   }

   // Método para modificar el mensaje
   public void setMessage(String newMessage){
      this.message = newMessage;
   }
}

