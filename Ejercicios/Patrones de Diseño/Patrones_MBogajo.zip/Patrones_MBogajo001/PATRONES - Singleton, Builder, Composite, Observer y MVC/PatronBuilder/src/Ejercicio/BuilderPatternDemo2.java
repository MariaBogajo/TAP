package Ejercicio;

public class BuilderPatternDemo2 {
    public static void main(String[] args) {
        
        MealBuilder mealBuilder = new MealBuilder();

        // Prueba 1: Crear nuevas comidas dentro del main
        Meal customMeal = new Meal();
        customMeal.addItem(new VegBurger());
        customMeal.addItem(new ChickenBurger());
        customMeal.addItem(new Coke());
        
        System.out.println("Custom Meal:");
        customMeal.showItems();
        System.out.println("Total Cost: " + customMeal.getCost());

        // Prueba 2: Modificación de una comida después de su construcción
        Meal modifiedMeal = mealBuilder.prepareVegMeal();
        modifiedMeal.addItem(new Pepsi()); // Agregar una bebida extra después de la construcción
        
        System.out.println("\n\nModified Meal:");
        modifiedMeal.showItems();
        System.out.println("Total Cost: " + modifiedMeal.getCost());

        // Prueba 3: Validación de costos
        Meal vegMeal = mealBuilder.prepareVegMeal();
        Meal nonVegMeal = mealBuilder.prepareNonVegMeal();
        
        System.out.println("\n\nVeg Meal:");
        vegMeal.showItems();
        System.out.println("Total Cost: " + vegMeal.getCost());
        
        System.out.println("\n\nNon-Veg Meal:");
        nonVegMeal.showItems();
        System.out.println("Total Cost: " + nonVegMeal.getCost());
    }
}

