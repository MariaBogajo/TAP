package Ejercicio;

public interface Packing {
	   public String pack();
	}
