/**
 * 
 */
/**
 * 
 */
module PatronFacade {
	requires java.desktop;
}