package Ejercicio;
import java.awt.Graphics;

public class Triangle implements Shape {
    @Override
    public void draw(Graphics g) {
        int[] xPoints = {150, 100, 200};
        int[] yPoints = {50, 150, 150};
        g.drawPolygon(xPoints, yPoints, 3);
    }
}
