package Ejercicio;
import java.util.ArrayList;

public class EmptyShapeMaker extends ShapeMaker {
    public EmptyShapeMaker() {
        super(); 
        shapes = new ArrayList<>(); // Ahora podemos modificar 'shapes' sin error
    }

    public static void main(String[] args) {
        EmptyShapeMaker emptyMaker = new EmptyShapeMaker();
        System.out.println("PRUEBA 2: Dibujar con fachada vacía");
        emptyMaker.drawShapes(null); // No debería lanzar error, pero tampoco dibujar nada.
    }
}
