package Ejercicio;
import javax.swing.JFrame;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("Dibujando Figuras");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        ShapePanel panel = new ShapePanel();
        add(panel);

        // Agregar figuras a la ventana
        panel.addShape(new Circle());
        panel.addShape(new Rectangle());
        panel.addShape(new Square());

        setVisible(true);
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}

