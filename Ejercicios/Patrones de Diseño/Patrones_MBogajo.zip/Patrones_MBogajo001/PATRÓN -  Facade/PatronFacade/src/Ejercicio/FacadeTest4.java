package Ejercicio;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;

public class FacadeTest4 extends JFrame {
    private ShapeMaker shapeMaker;

    public FacadeTest4() {
        setTitle("PRUEBA 4: ¿Qué pasa si Graphics es null?");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        shapeMaker = new ShapeMaker();

        add(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    System.out.println("PRUEBA 4: Intentando dibujar con Graphics válido...");
                    shapeMaker.drawShapes(g);
                    System.out.println("✅ No hubo error, el dibujo se realizó correctamente.");
                } catch (Exception e) {
                    System.out.println("❌ Error detectado: " + e.getMessage());
                }
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new FacadeTest4(); // Ahora la prueba se hace en un entorno gráfico válido
    }
}

