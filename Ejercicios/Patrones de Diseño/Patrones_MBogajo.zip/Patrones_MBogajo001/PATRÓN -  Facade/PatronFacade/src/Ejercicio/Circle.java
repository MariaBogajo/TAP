package Ejercicio;
import java.awt.Graphics;

public class Circle implements Shape {

    @Override
    public void draw(Graphics g) {
        g.drawOval(50, 50, 100, 100); // Dibuja un círculo en (50,50) con radio 100
    }
}

