package Ejercicio;
import java.awt.Graphics;

public class Square implements Shape {

    @Override
    public void draw(Graphics g) {
        g.drawRect(200, 50, 100, 100); // Dibuja un cuadrado en (200,50) con lado 100
    }
}


