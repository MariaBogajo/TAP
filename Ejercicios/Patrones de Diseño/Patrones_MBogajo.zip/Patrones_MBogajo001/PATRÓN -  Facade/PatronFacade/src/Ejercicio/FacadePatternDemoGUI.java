package Ejercicio;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;

public class FacadePatternDemoGUI extends JFrame {
    private ShapeMaker shapeMaker;

    public FacadePatternDemoGUI() {
        setTitle("Patrón Facade - Dibujar Formas");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        shapeMaker = new ShapeMaker();

        add(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                shapeMaker.drawShapes(g); // Now correctly calling the method
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new FacadePatternDemoGUI(); // Test the Facade Pattern
    }
}

