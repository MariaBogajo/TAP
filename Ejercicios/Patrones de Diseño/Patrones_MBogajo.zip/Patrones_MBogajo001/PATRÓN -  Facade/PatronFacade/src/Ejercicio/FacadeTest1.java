package Ejercicio;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;

public class FacadeTest1 extends JFrame {
    private ShapeMaker shapeMaker;

    public FacadeTest1() {
        setTitle("PRUEBA 1: Dibujar con y sin fachada");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        shapeMaker = new ShapeMaker();

        add(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                System.out.println("Dibujando sin fachada...");
                new Circle().draw(g);
                new Rectangle().draw(g);
                new Square().draw(g);

                System.out.println("Dibujando con fachada...");
                shapeMaker.drawShapes(g);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new FacadeTest1(); // Abre la ventana con las pruebas gráficas
    }
}
