package Ejercicio;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class ShapeMaker {
    // Cambiar 'private' a 'protected' para permitir acceso a subclases
    protected List<Shape> shapes;

    public ShapeMaker() {
        shapes = new ArrayList<>();
        shapes.add(new Circle());
        shapes.add(new Rectangle());
        shapes.add(new Square());
    }

    public void drawShapes(Graphics g) {
        for (Shape shape : shapes) {
            shape.draw(g);
        }
    }
}